<?php

	$module_info['name'] = 'Admin GroupDocs Viewer';

	$module_info['desc'] = 'Add Word, Exel, PDF, Images and other files using GroupDocs File ID';

	$module_info['version'] = 1.0;


?>